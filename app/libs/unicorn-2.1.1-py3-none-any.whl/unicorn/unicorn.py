class Uc:
    def __init__(self, arch, mode):
        raise NotImplementedError(
            "unicorn stub: local Anisette is not supported on Android. "
            "Use RemoteAnisetteProvider instead."
        )

    def mem_map(self, address, size, perms=7):
        raise NotImplementedError

    def mem_write(self, address, data):
        raise NotImplementedError

    def mem_read(self, address, length):
        raise NotImplementedError

    def reg_write(self, reg_id, value):
        raise NotImplementedError

    def reg_read(self, reg_id):
        raise NotImplementedError

    def hook_add(self, hook_type, callback, user_data=None, begin=1, end=0, arg1=0):
        raise NotImplementedError

    def emu_start(self, begin, until, timeout=0, count=0):
        raise NotImplementedError

    def emu_stop(self):
        raise NotImplementedError
